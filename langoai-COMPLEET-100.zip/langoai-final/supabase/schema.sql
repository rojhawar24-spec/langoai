-- ══════════════════════════════════════════════════
-- LangoAI — Supabase Database Schema
-- Uitvoeren in: Supabase Dashboard → SQL Editor
-- ══════════════════════════════════════════════════

-- 1. Profiles tabel (gekoppeld aan Supabase Auth)
CREATE TABLE IF NOT EXISTS public.profiles (
  id                 UUID        PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username           TEXT        UNIQUE NOT NULL,
  email              TEXT        NOT NULL,
  current_language   TEXT        DEFAULT NULL,
  total_xp           INTEGER     DEFAULT 0,
  level              INTEGER     DEFAULT 1,
  streak             INTEGER     DEFAULT 0,
  last_activity_date TEXT        DEFAULT NULL,
  theme              TEXT        DEFAULT 'light' CHECK (theme IN ('light', 'dark')),
  interface_language TEXT        DEFAULT 'en',
  premium            BOOLEAN     DEFAULT false,
  premium_expires_at TIMESTAMPTZ DEFAULT NULL,
  created_at         TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Row Level Security (RLS) inschakelen
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Gebruiker kan alleen zijn eigen profiel lezen
CREATE POLICY "Users can read own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

-- Gebruiker kan alleen zijn eigen profiel updaten
CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

-- Gebruiker kan zijn eigen profiel aanmaken (tijdens registratie)
CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- 3. Automatisch profiel aanmaken na registratie (trigger)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Profiel wordt aangemaakt vanuit de app na registratie
  -- Deze trigger is als fallback
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. Index voor snelle username-lookup (voor login met username)
CREATE INDEX IF NOT EXISTS profiles_username_idx ON public.profiles (LOWER(username));
CREATE INDEX IF NOT EXISTS profiles_email_idx    ON public.profiles (LOWER(email));

-- ══════════════════════════════════════════════════
-- 5. VEILIGE USERNAME → EMAIL LOOKUP (voor login)
-- ══════════════════════════════════════════════════
-- ⚠️ BELANGRIJK: de RLS-policy hierboven ("auth.uid() = id") betekent dat
-- een NIET-ingelogde gebruiker helemaal GEEN rij uit profiles mag lezen.
-- Dat brak in de praktijk de "log in met gebruikersnaam"-functie, want
-- de app moet vóór het inloggen (dus zonder sessie) de e-mail bij een
-- username kunnen opzoeken.
--
-- Oplossing: één smalle, veilige database-functie (SECURITY DEFINER) die
-- ALLEEN het e-mailadres teruggeeft — nooit de rest van het profiel
-- (geen XP, streak, premium-status, enz.). De onderliggende tabel blijft
-- via RLS volledig afgeschermd voor iedereen behalve de eigenaar.
CREATE OR REPLACE FUNCTION public.get_email_by_username(lookup_username TEXT)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  found_email TEXT;
BEGIN
  SELECT email INTO found_email
  FROM public.profiles
  WHERE LOWER(username) = LOWER(TRIM(lookup_username))
  LIMIT 1;

  RETURN found_email; -- geeft NULL terug als username niet bestaat
END;
$$;

-- Alleen uitvoerbaar (niet: rechtstreekse tabeltoegang) door anon/authenticated
GRANT EXECUTE ON FUNCTION public.get_email_by_username(TEXT) TO anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.get_email_by_username(TEXT) FROM PUBLIC;

-- ══════════════════════════════════════════════════
-- 6. VEILIGE USERNAME-BESCHIKBAARHEID CHECK (voor registratie)
-- ══════════════════════════════════════════════════
-- ⚠️ ZELFDE PROBLEEM ALS HIERBOVEN: vóór registratie is er nog geen
-- sessie, dus RLS blokkeerde de oude ".select('id').ilike('username',...)"
-- check volledig — die gaf altijd "niet gevonden" terug, ook als de
-- username al bestond. Resultaat: de check deed feitelijk niets.
--
-- Deze functie geeft ALLEEN true/false terug — geen enkele profieldata.
CREATE OR REPLACE FUNCTION public.username_available(check_username TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE LOWER(username) = LOWER(TRIM(check_username))
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.username_available(TEXT) TO anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.username_available(TEXT) FROM PUBLIC;
