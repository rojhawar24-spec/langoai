// api/chat.js — Claude AI chat endpoint
// ✅ Rate limiting: max 15 requests per minuut per IP
// ✅ CORS: alleen eigen domein
// ✅ Token verificatie via KV
// ✅ Geen hardcoded secrets

import { kv } from "@vercel/kv";

// ── CORS ────────────────────────────────────────
const ALLOWED_ORIGIN = process.env.APP_ORIGIN || "https://langoaiapp.vercel.app";

function setCors(res, origin) {
  const allowed = origin === ALLOWED_ORIGIN || origin === "http://localhost:5173";
  res.setHeader("Access-Control-Allow-Origin", allowed ? origin : ALLOWED_ORIGIN);
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Vary", "Origin");
}

// ── RATE LIMITING ────────────────────────────────
// Max 15 requests per minuut per IP
async function checkRateLimit(ip) {
  const key = `rate:chat:${ip}`;
  try {
    const count = await kv.incr(key);
    if (count === 1) {
      await kv.expire(key, 60); // Reset elke 60 seconden
    }
    return count <= 15;
  } catch {
    return true; // Bij KV fout: niet blokkeren
  }
}

// ── HANDLER ──────────────────────────────────────
export default async function handler(req, res) {
  const origin = req.headers.origin || "";
  setCors(res, origin);

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });

  // Rate limiting op IP
  const ip =
    req.headers["x-forwarded-for"]?.split(",")[0]?.trim() ||
    req.socket?.remoteAddress ||
    "unknown";

  const allowed = await checkRateLimit(ip);
  if (!allowed) {
    return res.status(429).json({
      error: "Too many requests. Wait 1 minute and try again.",
    });
  }

  // API key check
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "Claude API key missing on server" });
  }

  const { messages, systemPrompt, maxTokens, accessToken } = req.body || {};

  // ── PAYMENT GATE ────────────────────────────────
  if (!accessToken) {
    return res.status(401).json({ error: "No access token. Please pay first." });
  }

  try {
    const tokenData = await kv.get(`token:${accessToken}`);

    if (!tokenData || !tokenData.valid) {
      return res.status(401).json({ error: "Invalid access token." });
    }

    if (new Date(tokenData.expiresAt).getTime() < Date.now()) {
      await kv.del(`token:${accessToken}`);
      return res.status(401).json({ error: "Access expired. Please pay again." });
    }
  } catch (err) {
    console.error("Token check error:", err);
    return res.status(500).json({ error: "Could not verify payment. Try again." });
  }
  // ────────────────────────────────────────────────

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Missing messages" });
  }

  // Valideer berichten
  for (const msg of messages) {
    if (!msg.role || !msg.content || typeof msg.content !== "string") {
      return res.status(400).json({ error: "Invalid message format" });
    }
    if (msg.content.length > 4000) {
      return res.status(400).json({ error: "Message too long (max 4000 chars)" });
    }
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-3-5-haiku-20241022",
        max_tokens: Math.min(maxTokens || 500, 1000), // Max 1000 tokens
        system: systemPrompt || "You are a helpful language tutor.",
        messages,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("Claude error:", response.status, errText.slice(0, 300));
      return res.status(response.status).json({ error: `Claude error ${response.status}` });
    }

    const data = await response.json();
    const text = data.content?.[0]?.text ?? "";
    return res.json({ text });
  } catch (err) {
    console.error("Chat error:", err);
    return res.status(500).json({ error: "Server error" });
  }
}
