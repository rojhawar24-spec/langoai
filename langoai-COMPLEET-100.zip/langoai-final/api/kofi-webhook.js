// api/kofi-webhook.js — ✅ FIX BUG-05: CORS restricted to own domain

import { kv } from "@vercel/kv";

const ALLOWED_ORIGIN = process.env.APP_ORIGIN || "https://langoaiapp.vercel.app";

// ✅ FIX: geen wildcard meer
function setCors(res, origin) {
  const allowed =
    origin === ALLOWED_ORIGIN || origin === "http://localhost:5173";
  res.setHeader("Access-Control-Allow-Origin", allowed ? origin : ALLOWED_ORIGIN);
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Vary", "Origin");
}

function parseKofiPayload(body) {
  if (!body) return null;
  if (typeof body === "string") {
    try {
      const params = new URLSearchParams(body);
      const data = params.get("data");
      return data ? JSON.parse(data) : JSON.parse(body);
    } catch {
      return null;
    }
  }
  if (body.data) {
    try { return typeof body.data === "string" ? JSON.parse(body.data) : body.data; }
    catch { return null; }
  }
  return body;
}

export default async function handler(req, res) {
  const origin = req.headers.origin || "";
  setCors(res, origin);

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });

  const payload = parseKofiPayload(req.body);
  if (!payload) return res.status(400).json({ error: "Invalid payload" });

  const verificationToken = process.env.KOFI_VERIFICATION_TOKEN;
  if (verificationToken && payload.verification_token !== verificationToken) {
    return res.status(403).json({ error: "Invalid verification token" });
  }

  const email = payload.email?.toLowerCase();
  const amount = parseFloat(payload.amount || "0");
  const currency = payload.currency || "USD";
  const kofiTransactionId = payload.kofi_transaction_id;

  if (!email || !kofiTransactionId) {
    return res.status(400).json({ error: "Missing email or transaction ID" });
  }

  const premiumPrice = parseFloat(process.env.PREMIUM_PRICE_EUR || "4.00");
  const isPremiumPayment = amount >= premiumPrice;

  if (!isPremiumPayment) {
    return res.json({ success: true, message: "Thank you for your support!" });
  }

  try {
    const accessToken = `kt_${kofiTransactionId}_${Date.now()}`;
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

    await kv.set(
      `token:${accessToken}`,
      { valid: true, email, amount, currency, kofiTransactionId, expiresAt, grantedAt: new Date().toISOString() },
      { ex: 30 * 24 * 60 * 60 }
    );

    await kv.set(
      `email:${email}:token`,
      { accessToken, expiresAt },
      { ex: 30 * 24 * 60 * 60 }
    );

    return res.json({ success: true, message: "Premium access granted!" });
  } catch (err) {
    console.error("KV error:", err);
    return res.status(500).json({ error: "Could not store token" });
  }
}
