// src/contexts/AuthContext.tsx
// ✅ DEFINITIEF CORRECT:
//    - Importeert UserData (camelCase) uit storage.ts
//    - Houdt memory cache bij via setCurrentUser()
//    - createXPAwarder(updateProfile) werkt hierdoor ongewijzigd in alle 5 pagina's

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  type ReactNode,
} from "react";
import { supabase } from "@/lib/supabase";
import {
  type UserData,
  rowToUser,
  userToRow,
  setCurrentUser,
  apiGetMe,
  apiLogout,
  apiUpdateUser,
} from "@/utils/storage";

interface AuthContextType {
  user: UserData | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (user: UserData) => void;
  logout: () => void;
  refreshUser: () => void;
  updateProfile: (updates: Partial<UserData>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Controleer sessie bij opstarten
    apiGetMe().then((u) => {
      setUser(u);
      setIsLoading(false);
    });

    // Luister naar login/logout events van Supabase
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        if (session?.user) {
          // ⚠️ 2FA-GATE: als deze gebruiker TOTP heeft ingeschakeld en de
          // sessie nog geen aal2 heeft bereikt, NIET inloggen. Anders zou
          // deze listener de 2FA-check in apiLogin() volledig omzeilen —
          // elke sessie (ook meteen na een correct wachtwoord, vóór de
          // code is ingevoerd) zou anders al als "ingelogd" gelden.
          const { data: aal } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
          if (aal && aal.nextLevel === "aal2" && aal.currentLevel !== "aal2") {
            return; // Wacht tot de 2FA-code geverifieerd is (zie LoginPage)
          }

          const { data: profile } = await supabase
            .from("profiles")
            .select("*")
            .eq("id", session.user.id)
            .single();

          if (profile) {
            const userData = rowToUser(profile);
            setCurrentUser(userData); // ✅ Update memory cache
            setUser(userData);
          }
        } else {
          setCurrentUser(null); // ✅ Clear memory cache
          setUser(null);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const login = useCallback((userData: UserData) => {
    setCurrentUser(userData); // ✅ Update memory cache
    setUser(userData);
  }, []);

  const logout = useCallback(async () => {
    await apiLogout(); // apiLogout roept ook setCurrentUser(null) aan
    setUser(null);
  }, []);

  const refreshUser = useCallback(async () => {
    const u = await apiGetMe(); // apiGetMe roept ook setCurrentUser() aan
    setUser(u);
  }, []);

  const updateProfile = useCallback(
    async (updates: Partial<UserData>) => {
      if (!user) return;

      try {
        // Optie A: via Supabase (als ingelogd)
        const { data: { session } } = await supabase.auth.getSession();

        if (session?.user) {
          const { data, error } = await supabase
            .from("profiles")
            .update(userToRow(updates))
            .eq("id", user.id)
            .select()
            .single();

          if (!error && data) {
            const updated = rowToUser(data);
            setCurrentUser(updated); // ✅ Update memory cache
            setUser(updated);
          }
        } else {
          // Fallback: lokaal updaten (geen sessie beschikbaar)
          const updated = { ...user, ...updates };
          setCurrentUser(updated);
          setUser(updated);
        }
      } catch (err) {
        console.error("updateProfile fout:", err);
        // Fallback: lokaal updaten zodat de UI niet vastloopt
        const updated = { ...user, ...updates };
        setCurrentUser(updated);
        setUser(updated);
      }
    },
    [user]
  );

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        logout,
        refreshUser,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return ctx;
}
