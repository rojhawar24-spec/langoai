// src/i18n/I18nContext.tsx
// ✅ FIXED: leer-taal = app-taal
//    Als iemand Nederlands kiest → hele app wordt Nederlands
//    Als iemand Engels kiest → hele app wordt Engels

import {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
  type ReactNode,
} from "react";
import { useAuth } from "@/contexts/AuthContext";
import {
  type UILanguage,
  type TranslationKey,
  getTranslation as getTrans,
} from "@/i18n/translations";

interface I18nContextType {
  uiLanguage: UILanguage;
  setUILanguage: (lang: UILanguage) => void;
  t: (key: TranslationKey) => string;
}

const I18nContext = createContext<I18nContextType | null>(null);
const STORAGE_KEY = "langlearn_ui_language";

const VALID_LANGS: UILanguage[] = ["en", "nl", "fr", "de", "es"];

function getStoredLanguage(): UILanguage {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw && VALID_LANGS.includes(raw as UILanguage)) {
      return raw as UILanguage;
    }
  } catch { /* ignore */ }
  return "en";
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const { user, updateProfile, isAuthenticated } = useAuth();
  const [uiLanguage, setUILanguageState] = useState<UILanguage>(getStoredLanguage);

  // ✅ Als leer-taal verandert → app-taal ook veranderen
  useEffect(() => {
    if (!isAuthenticated || !user?.currentLanguage) return;

    const lang = user.currentLanguage as UILanguage;
    if (!VALID_LANGS.includes(lang)) return;

    // App-taal instellen op leer-taal
    setUILanguageState(lang);
    localStorage.setItem(STORAGE_KEY, lang);

    // ✅ Beide synchroon opslaan in profiel
    if (user.interfaceLanguage !== lang) {
      updateProfile({ interfaceLanguage: lang });
    }
  }, [user?.currentLanguage]); // ✅ Alleen leer-taal als trigger

  // ✅ App-taal handmatig wijzigen (via Settings)
  const setUILanguage = useCallback(
    (lang: UILanguage) => {
      setUILanguageState(lang);
      localStorage.setItem(STORAGE_KEY, lang);
      if (isAuthenticated && user) {
        // ✅ Beide bijwerken — app-taal EN leer-taal
        updateProfile({ interfaceLanguage: lang, currentLanguage: lang });
      }
    },
    [isAuthenticated, user, updateProfile]
  );

  const t = useCallback(
    (key: TranslationKey): string => getTrans(uiLanguage, key),
    [uiLanguage]
  );

  return (
    <I18nContext.Provider value={{ uiLanguage, setUILanguage, t }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useTranslate(): I18nContextType {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useTranslate must be used within an I18nProvider");
  return ctx;
}
