import { useState, useCallback, lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { SpeedInsights } from "@vercel/speed-insights/react";
import { AuthProvider } from "@/contexts/AuthContext";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { I18nProvider } from "@/i18n/I18nContext";
import ScrollToTop from "@/components/ScrollToTop";
import { PageSkeleton, DashboardSkeleton } from "@/components/Skeleton";
import ProtectedRoute from "@/components/ProtectedRoute";
import TopBar from "@/components/TopBar";
import BottomNav from "@/components/BottomNav";
import Footer from "@/components/Footer";
import FloatingChatButton from "@/components/FloatingChatButton";
import AIChat from "@/components/AIChat";
import CookieBanner from "@/components/CookieBanner";
import SplashScreen from "@/components/SplashScreen";
import OfflineBanner from "@/components/OfflineBanner";
import ScrollToTopButton from "@/components/ScrollToTopButton";
import LoginPage from "@/pages/LoginPage";
import RegisterPage from "@/pages/RegisterPage";

// Preload dashboard immediately
const preloadDashboard = () => import("@/pages/DashboardPage");
preloadDashboard();

// Lazy imports
const DashboardPage     = lazy(() => import("@/pages/DashboardPage"));
const ProfilePage       = lazy(() => import("@/pages/ProfilePage"));
const SettingsPage      = lazy(() => import("@/pages/SettingsPage"));
const PremiumPage       = lazy(() => import("@/pages/PremiumPage"));
const GrammarPage       = lazy(() => import("@/pages/GrammarPage"));
const VocabularyPage    = lazy(() => import("@/pages/VocabularyPage"));
const TestPage          = lazy(() => import("@/pages/TestPage"));
const MistakesPage      = lazy(() => import("@/pages/MistakesPage"));
const PrivacyPolicyPage = lazy(() => import("@/pages/PrivacyPolicyPage"));
const TermsPage         = lazy(() => import("@/pages/TermsPage"));
const WordOfTheDayPage  = lazy(() => import("@/pages/WordOfTheDayPage"));
const ArenaPage         = lazy(() => import("@/pages/ArenaPage"));
const ResetPasswordPage = lazy(() => import("@/pages/ResetPasswordPage"));

// ── AuthenticatedLayout ──────────────────────────────────────────────────────
function AuthenticatedLayout({ children }: { children: React.ReactNode }) {
  const [chatOpen, setChatOpen] = useState(false);
  const openChat  = useCallback(() => setChatOpen(true),  []);
  const closeChat = useCallback(() => setChatOpen(false), []);

  return (
    <div className="flex min-h-screen flex-col">
      <TopBar />
      <main className="flex-1 pb-24 lg:pb-8">{children}</main>
      <div className="hidden lg:block"><Footer /></div>
      <BottomNav onOpenChat={openChat} />
      <FloatingChatButton onClick={openChat} />
      <AIChat open={chatOpen} onClose={closeChat} />
    </div>
  );
}

// ── LazyPage ─────────────────────────────────────────────────────────────────
const LazyPage = ({ children, dashboard }: { children: React.ReactNode; dashboard?: boolean }) => (
  <Suspense fallback={dashboard ? <DashboardSkeleton /> : <PageSkeleton />}>
    {children}
  </Suspense>
);

// ── ProtectedRouteWrapper ────────────────────────────────────────────────────
const ProtectedRouteWrapper = ({ children }: { children: React.ReactNode }) => (
  <ProtectedRoute>{children}</ProtectedRoute>
);

// ── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  // ✅ splashDone in App — toont 1 keer bij opstarten, niet bij elke navigatie
  const [splashDone, setSplashDone] = useState(false);

  return (
    <BrowserRouter>
      {/* ✅ SplashScreen — 1 keer bij opstarten */}
      {!splashDone && <SplashScreen onDone={() => setSplashDone(true)} />}

      <AuthProvider>
        <ThemeProvider>
          <I18nProvider>
            <ScrollToTop />
            <SpeedInsights />
            <OfflineBanner />
            <CookieBanner />
            <ScrollToTopButton />
            <Routes>
              {/* Public routes */}
              <Route path="/login"          element={<><LoginPage /><Footer minimal /></>} />
              <Route path="/register"       element={<><RegisterPage /><Footer minimal /></>} />
              <Route path="/reset-password" element={<LazyPage><ResetPasswordPage /></LazyPage>} />
              <Route path="/privacy"        element={<LazyPage><AuthenticatedLayout><PrivacyPolicyPage /></AuthenticatedLayout></LazyPage>} />
              <Route path="/terms"          element={<LazyPage><AuthenticatedLayout><TermsPage /></AuthenticatedLayout></LazyPage>} />

              {/* Protected routes */}
              <Route path="/dashboard"  element={<ProtectedRouteWrapper><LazyPage dashboard><AuthenticatedLayout><DashboardPage /></AuthenticatedLayout></LazyPage></ProtectedRouteWrapper>} />
              <Route path="/grammar"    element={<ProtectedRouteWrapper><LazyPage><AuthenticatedLayout><GrammarPage /></AuthenticatedLayout></LazyPage></ProtectedRouteWrapper>} />
              <Route path="/vocabulary" element={<ProtectedRouteWrapper><LazyPage><AuthenticatedLayout><VocabularyPage /></AuthenticatedLayout></LazyPage></ProtectedRouteWrapper>} />
              <Route path="/tests"      element={<ProtectedRouteWrapper><LazyPage><AuthenticatedLayout><TestPage /></AuthenticatedLayout></LazyPage></ProtectedRouteWrapper>} />
              <Route path="/profile"    element={<ProtectedRouteWrapper><LazyPage><AuthenticatedLayout><ProfilePage /></AuthenticatedLayout></LazyPage></ProtectedRouteWrapper>} />
              <Route path="/settings"   element={<ProtectedRouteWrapper><LazyPage><AuthenticatedLayout><SettingsPage /></AuthenticatedLayout></LazyPage></ProtectedRouteWrapper>} />
              <Route path="/premium"    element={<ProtectedRouteWrapper><LazyPage><AuthenticatedLayout><PremiumPage /></AuthenticatedLayout></LazyPage></ProtectedRouteWrapper>} />
              <Route path="/mistakes"   element={<ProtectedRouteWrapper><LazyPage><AuthenticatedLayout><MistakesPage /></AuthenticatedLayout></LazyPage></ProtectedRouteWrapper>} />
              <Route path="/wotd"       element={<ProtectedRouteWrapper><LazyPage><AuthenticatedLayout><WordOfTheDayPage /></AuthenticatedLayout></LazyPage></ProtectedRouteWrapper>} />
              <Route path="/arena"      element={<ProtectedRouteWrapper><LazyPage><AuthenticatedLayout><ArenaPage /></AuthenticatedLayout></LazyPage></ProtectedRouteWrapper>} />

              {/* Fallback */}
              <Route path="/"  element={<Navigate to="/dashboard" replace />} />
              <Route path="*"  element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </I18nProvider>
        </ThemeProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
