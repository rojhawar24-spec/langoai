// src/components/CookieBanner.tsx
// ✅ GDPR verplicht — Cookie toestemmingsbanner
// Toont bij eerste bezoek — verdwijnt na accepteren of weigeren

import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useTranslate } from "@/i18n/I18nContext";

const COOKIE_KEY = "langlearn_cookie_consent";

export type CookieConsent = "accepted" | "declined" | null;

export function getCookieConsent(): CookieConsent {
  try {
    const val = localStorage.getItem(COOKIE_KEY);
    if (val === "accepted" || val === "declined") return val;
  } catch { /* ignore */ }
  return null;
}

export default function CookieBanner() {
  const { t } = useTranslate();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Toon banner alleen als er nog geen keuze is gemaakt
    if (getCookieConsent() === null) {
      // Kleine vertraging zodat de pagina eerst laadt
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  function accept() {
    localStorage.setItem(COOKIE_KEY, "accepted");
    setVisible(false);
    // Laad Google AdSense na acceptatie
    try {
      const script = document.createElement("script");
      script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2793563271769362";
      script.async = true;
      script.crossOrigin = "anonymous";
      document.head.appendChild(script);
    } catch { /* ignore */ }
  }

  function decline() {
    localStorage.setItem(COOKIE_KEY, "declined");
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div
      role="dialog"
      aria-modal="false"
      aria-label="Cookie toestemming"
      className="fixed bottom-20 left-3 right-3 z-50 mx-auto max-w-lg animate-in slide-in-from-bottom-4 duration-300 lg:bottom-6 lg:left-6 lg:right-auto lg:max-w-md"
    >
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl shadow-slate-900/10 dark:border-slate-700 dark:bg-slate-800">

        {/* Header */}
        <div className="flex items-center gap-3 border-b border-slate-100 bg-slate-50 px-5 py-4 dark:border-slate-700 dark:bg-slate-900">
          <span className="text-2xl" aria-hidden="true">🍪</span>
          <div>
            <p className="text-sm font-bold text-slate-900 dark:text-white">
              {t("cookie.title")}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              GDPR / AVG — België · EU
            </p>
          </div>
        </div>

        {/* Inhoud */}
        <div className="px-5 py-4">
          <p className="text-xs leading-5 text-slate-600 dark:text-slate-300">
            {t("cookie.description")}{" "}
            <Link
              to="/privacy"
              className="font-semibold text-indigo-600 underline hover:text-indigo-500 dark:text-indigo-400"
            >
              {t("cookie.privacy_link")}
            </Link>
          </p>

          <div className="mt-2 space-y-1 text-xs text-slate-500 dark:text-slate-400">
            <p>✅ {t("cookie.necessary")} — {t("cookie.necessary_desc")}</p>
            <p>📊 {t("cookie.analytics")} — {t("cookie.analytics_desc")}</p>
            <p>📢 {t("cookie.advertising")} — {t("cookie.advertising_desc")}</p>
          </div>
        </div>

        {/* Knoppen */}
        <div className="flex gap-2 border-t border-slate-100 px-5 py-4 dark:border-slate-700">
          <button
            onClick={decline}
            className="flex-1 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-50 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-slate-600"
          >
            {t("cookie.decline")}
          </button>
          <button
            onClick={accept}
            className="flex-1 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-semibold text-white transition hover:bg-indigo-700 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          >
            {t("cookie.accept")}
          </button>
        </div>

      </div>
    </div>
  );
}
