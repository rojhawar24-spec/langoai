// src/hooks/useStreakReconciler.ts
// ✅ CORRECT: gebruikt user.lastActivityDate (camelCase) — werkt in de hele app

import { useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { reconcileStreak, bootstrapStreakData } from "@/utils/streak";

export function useStreakReconciler() {
  const { user, updateProfile } = useAuth();

  useEffect(() => {
    if (!user) return;

    // ✅ camelCase — werkt direct, geen snake_case nodig
    bootstrapStreakData(user.lastActivityDate ?? null);

    const { streak, changed } = reconcileStreak(user.streak ?? 0);

    if (changed) {
      updateProfile({ streak });
    }
  }, [user?.id]); // alleen opnieuw draaien als gebruiker wisselt
}
