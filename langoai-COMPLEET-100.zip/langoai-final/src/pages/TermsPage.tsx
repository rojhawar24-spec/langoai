// src/pages/TermsPage.tsx
// ✅ Volledig conforme Gebruiksvoorwaarden — Belgisch/EU recht
//    Verplicht o.b.v.: Wet Consumentenrechten (BE), E-commercewet, GDPR

import { useNavigate } from "react-router-dom";

export default function TermsPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <button
          onClick={() => navigate(-1)}
          className="mb-6 inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-600 shadow-sm transition hover:border-indigo-200 hover:bg-indigo-50 hover:text-indigo-700 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300"
        >
          <span aria-hidden="true">←</span>
          Terug / Back
        </button>

        <h1 className="mb-2 text-3xl font-extrabold text-slate-900 dark:text-white">
          Gebruiksvoorwaarden / Terms of Service
        </h1>
        <p className="mb-2 text-sm text-slate-500 dark:text-slate-400">
          Laatste update / Last updated: 1 juli 2026
        </p>
        <p className="mb-8 text-xs text-slate-400 dark:text-slate-500">
          Van toepassing op / Applicable to: langoaiapp.vercel.app · België / Belgium
        </p>

        <div className="space-y-10 text-sm leading-relaxed text-slate-700 dark:text-slate-300">

          {/* 1. Aanbieder */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              1. Aanbieder / Service Provider
            </h2>
            <p className="mb-2">
              <strong>Lango AI</strong> wordt aangeboden door een in België gevestigde aanbieder.
            </p>
            <p className="mb-2">
              Contact:{" "}
              <a href="mailto:legal@langoai.com" className="text-indigo-600 underline dark:text-indigo-400">
                legal@langoai.com
              </a>
            </p>
            <p className="text-xs text-slate-400">
              Door gebruik te maken van Lango AI ga je akkoord met deze gebruiksvoorwaarden.
              Bij gebruik door personen jonger dan 16 jaar is toestemming van ouders/voogd vereist.
            </p>
          </section>

          {/* 2. Dienst */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              2. De dienst
            </h2>
            <p className="mb-2">
              Lango AI is een online taalleerplatform met grammaticale lessen, woordenschatoefeningen,
              tests, dagelijks woord, en (binnenkort) een AI Tutor powered by Claude (Anthropic).
            </p>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
                <p className="font-semibold text-slate-800 dark:text-slate-200">🆓 Gratis</p>
                <p className="mt-1 text-xs text-slate-500">Lessen, woordenschat, tests, oefeningen, streak. Eventueel met advertenties.</p>
              </div>
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 dark:border-amber-800 dark:bg-amber-950/20">
                <p className="font-semibold text-amber-800 dark:text-amber-300">⭐ AI Premium — €4 / 30 dagen</p>
                <p className="mt-1 text-xs text-amber-700 dark:text-amber-400">
                  Éénmalige betaling van €4 via Ko-fi geeft 30 dagen toegang tot de AI Tutor.
                  Dit is <strong>geen abonnement</strong>. Na 30 dagen eindigt de toegang automatisch.
                </p>
              </div>
            </div>
          </section>

          {/* 3. Account */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              3. Account en registratie
            </h2>
            <ul className="ml-5 list-disc space-y-1">
              <li>Geef correcte en volledige informatie bij registratie.</li>
              <li>Houd je inloggegevens geheim — deel ze niet met anderen.</li>
              <li>Maximaal één account per persoon.</li>
              <li>Je bent verantwoordelijk voor alle activiteit onder jouw account.</li>
              <li>Meld onmiddellijk ongeautoriseerd gebruik via legal@langoai.com.</li>
            </ul>
          </section>

          {/* 4. Betaling */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              4. Betaling, herroepingsrecht en terugbetaling
            </h2>
            <p className="mb-2">
              <strong>Prijs:</strong> €4,00 per 30 dagen AI Tutor toegang (incl. BTW indien van toepassing).
            </p>
            <p className="mb-2">
              <strong>Betaalwijze:</strong> Ko-fi (via PayPal of creditkaart).
            </p>

            <div className="mt-3 rounded-xl border border-orange-200 bg-orange-50 p-4 dark:border-orange-800 dark:bg-orange-950/20">
              <p className="text-xs font-bold text-orange-800 dark:text-orange-300">
                ⚠️ Herroepingsrecht (EU Consumentenrichtlijn 2011/83/EU)
              </p>
              <p className="mt-1 text-xs text-orange-700 dark:text-orange-400">
                Normaal heb je als consument 14 dagen herroepingsrecht. Omdat de AI toegang
                onmiddellijk na betaling start en je hiermee uitdrukkelijk instemt,
                verlies je het herroepingsrecht zodra de dienst is gestart (art. 16.m Richtlijn).
                <br /><br />
                Bij technische problemen van onze kant word je vergoed. Neem contact op via
                legal@langoai.com.
              </p>
            </div>

            <p className="mt-2 text-xs text-slate-400">
              Betalingen worden verwerkt door Ko-fi/PayPal. Wij ontvangen alleen een
              betalingsbevestiging — geen volledige betaalgegevens.
            </p>
          </section>

          {/* 5. Gedragsregels */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              5. Gedragsregels / Acceptable Use
            </h2>
            <p className="mb-2">Het is <strong>niet</strong> toegestaan om:</p>
            <ul className="ml-5 list-disc space-y-1">
              <li>De dienst te gebruiken voor illegale doeleinden</li>
              <li>Ongeautoriseerde toegang te proberen (hacking, exploits)</li>
              <li>Geautomatiseerde bots of scrapers te gebruiken</li>
              <li>Schadelijke, beledigende of illegale inhoud via de AI te genereren</li>
              <li>Meerdere accounts aan te maken om gratis voordelen te omzeilen</li>
              <li>De AI Tutor te gebruiken voor andere doeleinden dan taalleren</li>
            </ul>
            <p className="mt-2 text-xs text-slate-400">
              Overtredingen kunnen leiden tot onmiddellijke opschorting van het account,
              zonder terugbetaling van premium toegang.
            </p>
          </section>

          {/* 6. Intellectueel eigendom */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              6. Intellectuele eigendom
            </h2>
            <p className="mb-2">
              Alle inhoud van Lango AI — lessen, tests, teksten, ontwerp, code, logo — is eigendom van
              Lango AI of haar licentiegevers en beschermd door intellectuele eigendomsrechten.
            </p>
            <p>
              Jouw leergegevens (voortgang, antwoorden, XP) blijven van jou.
              Je verleent ons geen rechten op de inhoud van je AI chats.
            </p>
          </section>

          {/* 7. AI disclaimer */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              7. AI Tutor — Disclaimer
            </h2>
            <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
              <ul className="space-y-1 text-xs text-slate-500 dark:text-slate-400">
                <li>• De AI Tutor wordt aangedreven door Claude (Anthropic) en is een <strong>hulpmiddel</strong> — geen gecertificeerde taaldocent.</li>
                <li>• AI-antwoorden kunnen fouten bevatten. Controleer altijd bij twijfel.</li>
                <li>• Gebruik de AI Tutor alleen voor taalleren — niet voor medisch, juridisch of financieel advies.</li>
                <li>• Anthropic verwerkt je AI chatberichten conform hun privacybeleid.</li>
              </ul>
            </div>
          </section>

          {/* 8. Aansprakelijkheid */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              8. Aansprakelijkheidsbeperking
            </h2>
            <p className="mb-2">
              De dienst wordt geleverd "as is" en "as available". Wij garanderen geen:
            </p>
            <ul className="ml-5 list-disc space-y-1">
              <li>Ononderbroken beschikbaarheid van de dienst</li>
              <li>Specifieke leerresultaten of taalvorderingen</li>
              <li>Foutloze AI-antwoorden</li>
            </ul>
            <p className="mt-2 text-xs text-slate-400">
              Onze aansprakelijkheid is beperkt tot het bedrag dat je in de voorgaande 30 dagen hebt betaald,
              tenzij schade het gevolg is van opzet of grove nalatigheid.
              Belgisch recht is van toepassing — dwingende consumentenbeschermingsbepalingen blijven geldig.
            </p>
          </section>

          {/* 9. Wijzigingen */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              9. Wijzigingen in de dienst of voorwaarden
            </h2>
            <p>
              Wij behouden ons het recht voor de dienst of deze voorwaarden te wijzigen.
              Bij wezenlijke wijzigingen word je minstens 30 dagen op voorhand geïnformeerd
              via e-mail of in-app melding. Voortgezet gebruik na de ingangsdatum houdt
              aanvaarding van de nieuwe voorwaarden in.
            </p>
          </section>

          {/* 10. Toepasselijk recht */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              10. Toepasselijk recht en geschillenbeslechting
            </h2>
            <p className="mb-2">
              Deze voorwaarden zijn onderworpen aan <strong>Belgisch recht</strong>.
            </p>
            <p className="mb-2">
              Bij geschillen proberen we eerst een minnelijke oplossing te vinden.
              Je kunt ook gebruik maken van de{" "}
              <a
                href="https://ec.europa.eu/consumers/odr"
                target="_blank"
                rel="noopener noreferrer"
                className="text-indigo-600 underline dark:text-indigo-400"
              >
                EU Online Dispute Resolution (ODR) platform
              </a>.
            </p>
            <p className="text-xs text-slate-400">
              Bevoegde rechtbank: rechtbanken van het arrondissement van de verweerder (België).
            </p>
          </section>

          {/* 11. Account verwijderen */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              11. Account verwijderen
            </h2>
            <p>
              Je kunt je account op elk moment verwijderen via Instellingen → Account → Account verwijderen.
              Jouw persoonsgegevens worden binnen 30 dagen gewist, behoudens wettelijke bewaarplicht
              (bv. boekhoudkundige gegevens — 7 jaar).
            </p>
          </section>

          {/* 12. Contact */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              12. Contact
            </h2>
            <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
              <p className="text-xs text-slate-600 dark:text-slate-300">
                📧{" "}
                <a href="mailto:legal@langoai.com" className="font-semibold text-indigo-600 underline dark:text-indigo-400">
                  legal@langoai.com
                </a>
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Reactie binnen 30 dagen.
              </p>
            </div>
          </section>

        </div>
      </div>
    </div>
  );
}
