// src/pages/SettingsPage.tsx
// ✅ FIXED: verifyPassword/hashPassword vervangen door Supabase auth
// ✅ FIXED BUG-10: leer-taal wijzigen verandert interfaceLanguage NIET meer
// ✅ FIXED BUG-17: window.confirm() vervangen door custom modal

import { useState, useEffect, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useTheme } from "@/contexts/ThemeContext";
import { useTranslate } from "@/i18n/I18nContext";
import { UI_LANGUAGES, type UILanguage } from "@/i18n/translations";
import { supabase } from "@/lib/supabase";

const LEARNING_LANGUAGES = [
  { code: "en", name: "English", flag: "🇬🇧" },
  { code: "nl", name: "Dutch",   flag: "🇳🇱" },
  { code: "fr", name: "French",  flag: "🇫🇷" },
  { code: "de", name: "German",  flag: "🇩🇪" },
  { code: "es", name: "Spanish", flag: "🇪🇸" },
];

type Tab = "account" | "preferences" | "learning" | "ai";

// ── Confirm Modal ────────────────────────────────────────────────────────
function ConfirmModal({
  title,
  message,
  onConfirm,
  onCancel,
}: {
  title: string;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm"
    >
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-700 dark:bg-slate-800">
        <h2 className="mb-2 text-lg font-bold text-slate-900 dark:text-white">{title}</h2>
        <p className="mb-6 text-sm text-slate-500 dark:text-slate-400">{message}</p>
        <div className="flex gap-3">
          <button type="button" onClick={onCancel}
            className="flex-1 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-100 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-200"
          >
            {t("generic.cancel")}
          </button>
          <button type="button" onClick={onConfirm}
            className="flex-1 rounded-xl bg-red-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-red-700"
          >
            {t("generic.save")}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Page ────────────────────────────────────────────────────────────
export default function SettingsPage() {
  const { user, updateProfile, logout } = useAuth();
  const { theme, setTheme }             = useTheme();
  const { uiLanguage, setUILanguage, t } = useTranslate();
  const navigate                         = useNavigate();
  const [activeTab, setActiveTab]        = useState<Tab>("account");

  if (!user) return null;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <div className="mx-auto max-w-4xl px-4 py-8 pb-28 sm:px-6">
        <button type="button" onClick={() => navigate("/dashboard")}
          aria-label={t("generic.back_dashboard")}
          className="mb-6 flex items-center gap-1 text-sm text-slate-500 transition hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400"
        >
          <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          {t("generic.back_dashboard")}
        </button>

        <h1 className="mb-8 text-2xl font-bold text-slate-900 dark:text-white sm:text-3xl">
          ⚙️ {t("settings.title")}
        </h1>

        {/* Tabs */}
        <div className="mb-6 flex gap-1 overflow-x-auto border-b border-slate-200 dark:border-slate-700 scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0">
          {(
            [
              ["account",     `🔑 ${t("settings.account")}`],
              ["preferences", `🎨 ${t("settings.preferences")}`],
              ["learning",    `📚 ${t("settings.learning")}`],
              ["ai",          `🤖 ${t("settings.ai_tab")}`],
            ] as [Tab, string][]
          ).map(([key, label]) => (
            <button type="button" key={key}
              onClick={() => setActiveTab(key)}
              className={`whitespace-nowrap rounded-t-lg px-5 py-3.5 text-sm font-semibold transition min-h-[44px] ${
                activeTab === key
                  ? "border-b-2 border-indigo-500 text-indigo-600 dark:text-indigo-400"
                  : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800">
          {activeTab === "account" && (
            <AccountSection
              user={user}
              logout={logout}
              navigate={navigate}
            />
          )}
          {activeTab === "preferences" && (
            <PreferencesSection
              theme={theme}
              setTheme={setTheme}
              uiLanguage={uiLanguage}
              setUILanguage={setUILanguage}
            />
          )}
          {activeTab === "learning" && (
            <LearningSection
              user={user}
              updateProfile={updateProfile}
              navigate={navigate}
              t={t}
            />
          )}
          {activeTab === "ai" && <AISettingsSection />}
        </div>
      </div>
    </div>
  );
}

// ── Account Section ──────────────────────────────────────────────────────
function AccountSection({
  user,
  logout,
  navigate,
}: {
  user: NonNullable<ReturnType<typeof useAuth>["user"]>;
  logout: ReturnType<typeof useAuth>["logout"];
  navigate: ReturnType<typeof useNavigate>;
}) {
  const [emailMsg,     setEmailMsg]     = useState("");
  const [passwordMsg,  setPasswordMsg]  = useState("");
  const [deleteInput,  setDeleteInput]  = useState("");
  const [deleteError,  setDeleteError]  = useState("");
  const [isDeleting,   setIsDeleting]   = useState(false);
  const [isLoading,    setIsLoading]    = useState(false);

  // ✅ Email wijzigen via Supabase Auth
  async function handleChangeEmail(e: FormEvent) {
    e.preventDefault();
    setEmailMsg("");
    setIsLoading(true);

    const form     = e.target as HTMLFormElement;
    const newEmail = (form.elements.namedItem("newEmail") as HTMLInputElement).value.trim();
    const pw       = (form.elements.namedItem("emailPassword") as HTMLInputElement).value;

    if (!newEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail)) {
      setEmailMsg("Please enter a valid email.");
      setIsLoading(false);
      return;
    }

    // Verify current password by re-signing in
    const { error: verifyErr } = await supabase.auth.signInWithPassword({
      email: user.email,
      password: pw,
    });

    if (verifyErr) {
      setEmailMsg("Current password is incorrect.");
      setIsLoading(false);
      return;
    }

    // Update email in Supabase Auth + profiles table
    const { error } = await supabase.auth.updateUser({ email: newEmail });
    if (error) {
      setEmailMsg("Failed to update email. " + error.message);
    } else {
      await supabase.from("profiles").update({ email: newEmail.toLowerCase() }).eq("id", user.id);
      setEmailMsg("✅ Email updated! Check your new email to confirm.");
      form.reset();
    }
    setIsLoading(false);
  }

  // ✅ Wachtwoord wijzigen via Supabase Auth
  async function handleChangePassword(e: FormEvent) {
    e.preventDefault();
    setPasswordMsg("");
    setIsLoading(true);

    const form      = e.target as HTMLFormElement;
    const currentPw = (form.elements.namedItem("currentPassword") as HTMLInputElement).value;
    const newPw     = (form.elements.namedItem("newPassword") as HTMLInputElement).value;
    const confirmPw = (form.elements.namedItem("confirmNewPassword") as HTMLInputElement).value;

    if (newPw.length < 8) {
      setPasswordMsg("New password must be at least 8 characters.");
      setIsLoading(false);
      return;
    }
    if (newPw !== confirmPw) {
      setPasswordMsg("New passwords do not match.");
      setIsLoading(false);
      return;
    }

    // Verify current password
    const { error: verifyErr } = await supabase.auth.signInWithPassword({
      email: user.email,
      password: currentPw,
    });
    if (verifyErr) {
      setPasswordMsg("Current password is incorrect.");
      setIsLoading(false);
      return;
    }

    // Update password
    const { error } = await supabase.auth.updateUser({ password: newPw });
    if (error) {
      setPasswordMsg("Failed to change password. " + error.message);
    } else {
      setPasswordMsg("✅ Password changed successfully!");
      form.reset();
    }
    setIsLoading(false);
  }

  const [isExporting,  setIsExporting]  = useState(false);
  const [exportError,  setExportError]  = useState("");

  async function handleExportData() {
    setExportError("");
    setIsExporting(true);
    try {
      // 1. Server-data: eigen profiel-rij (enige uit Supabase, dankzij RLS)
      const { data: profile, error: profileError } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();

      if (profileError) throw profileError;

      // 2. Lokale voortgangsdata (XP, streak, fouten, badges, chat, enz.)
      //    Dit staat op dit toestel in localStorage, niet op de server.
      const localData: Record<string, unknown> = {};
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (!key) continue;
        // Sla technische/niet-persoonlijke sleutels over
        if (key.startsWith("sb-") || key === "theme") continue;
        const raw = localStorage.getItem(key);
        try {
          localData[key] = raw ? JSON.parse(raw) : raw;
        } catch {
          localData[key] = raw;
        }
      }

      const exportBundle = {
        exportedAt: new Date().toISOString(),
        account: profile,
        localProgressData: localData,
      };

      const blob = new Blob([JSON.stringify(exportBundle, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `langoai-data-${user.username}-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch {
      setExportError("Data-export mislukt. Probeer het opnieuw.");
    } finally {
      setIsExporting(false);
    }
  }

  async function handleDeleteAccount() {
    if (deleteInput !== user.username) return;
    setDeleteError("");
    setIsDeleting(true);
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData.session?.access_token;
      if (!token) throw new Error("no_session");

      const res = await fetch("/api/delete-account", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) throw new Error("delete_failed");

      logout();
      navigate("/login", { replace: true });
    } catch {
      setDeleteError(
        "Account deletion failed. Please try again or contact support."
      );
      setIsDeleting(false);
    }
  }

  // ── 2FA (TOTP) ───────────────────────────────────────────────────────
  const [mfaFactors,   setMfaFactors]   = useState<{ id: string; friendlyName?: string }[]>([]);
  const [mfaLoading,   setMfaLoading]   = useState(true);
  const [mfaEnrolling, setMfaEnrolling] = useState(false);
  const [mfaQrCode,    setMfaQrCode]    = useState("");
  const [mfaSecret,    setMfaSecret]    = useState("");
  const [mfaFactorId,  setMfaFactorId]  = useState("");
  const [mfaCode,      setMfaCode]      = useState("");
  const [mfaError,     setMfaError]     = useState("");
  const [mfaBusy,      setMfaBusy]      = useState(false);

  async function loadMfaFactors() {
    setMfaLoading(true);
    try {
      const { data } = await supabase.auth.mfa.listFactors();
      setMfaFactors(data?.totp ?? []);
    } finally {
      setMfaLoading(false);
    }
  }

  // Bij openen van de pagina: bestaande 2FA-factoren ophalen
  useEffect(() => {
    loadMfaFactors();
  }, []);

  async function handleMfaStartEnroll() {
    setMfaError("");
    setMfaBusy(true);
    try {
      const { data, error } = await supabase.auth.mfa.enroll({ factorType: "totp" });
      if (error || !data) throw error;
      setMfaFactorId(data.id);
      setMfaQrCode(data.totp.qr_code);
      setMfaSecret(data.totp.secret);
      setMfaEnrolling(true);
    } catch {
      setMfaError("Could not start 2FA setup. Please try again.");
    } finally {
      setMfaBusy(false);
    }
  }

  async function handleMfaConfirmEnroll(e: FormEvent) {
    e.preventDefault();
    setMfaError("");
    if (!/^\d{6}$/.test(mfaCode.trim())) {
      setMfaError("Enter the 6-digit code from your authenticator app.");
      return;
    }
    setMfaBusy(true);
    try {
      const { data: challenge, error: challengeError } =
        await supabase.auth.mfa.challenge({ factorId: mfaFactorId });
      if (challengeError || !challenge) throw challengeError;

      const { error: verifyError } = await supabase.auth.mfa.verify({
        factorId: mfaFactorId,
        challengeId: challenge.id,
        code: mfaCode.trim(),
      });
      if (verifyError) throw verifyError;

      setMfaEnrolling(false);
      setMfaCode("");
      setMfaQrCode("");
      setMfaSecret("");
      await loadMfaFactors();
    } catch {
      setMfaError("Invalid code. Please try again.");
    } finally {
      setMfaBusy(false);
    }
  }

  async function handleMfaCancelEnroll() {
    // Ruim de niet-bevestigde factor weer op, anders blijft hij "pending" staan
    try {
      if (mfaFactorId) {
        await supabase.auth.mfa.unenroll({ factorId: mfaFactorId });
      }
    } catch {
      /* best effort */
    }
    setMfaEnrolling(false);
    setMfaCode("");
    setMfaQrCode("");
    setMfaSecret("");
    setMfaFactorId("");
    setMfaError("");
  }

  async function handleMfaRemove(factorId: string) {
    setMfaError("");
    setMfaBusy(true);
    try {
      const { error } = await supabase.auth.mfa.unenroll({ factorId });
      if (error) throw error;
      await loadMfaFactors();
    } catch {
      setMfaError("Could not remove 2FA. Please try again.");
    } finally {
      setMfaBusy(false);
    }
  }

  return (
    <div className="space-y-8">
      {/* {t("settings.changeEmail")} */}
      <div>
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-slate-400">
          Change Email
        </h3>
        <form onSubmit={handleChangeEmail} className="space-y-3">
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Current email
            </label>
            <input
              type="email"
              value={user.email}
              disabled
              className="mt-1 block w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-500 dark:border-slate-600 dark:bg-slate-800/50"
            />
          </div>
          <div>
            <label htmlFor="newEmail" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              New email
            </label>
            <input
              id="newEmail" name="newEmail" type="email"
              className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500 dark:border-slate-600 dark:bg-slate-800 dark:text-white"
            />
          </div>
          <div>
            <label htmlFor="emailPassword" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Current password (to confirm)
            </label>
            <input
              id="emailPassword" name="emailPassword" type="password"
              className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500 dark:border-slate-600 dark:bg-slate-800 dark:text-white"
            />
          </div>
          {emailMsg && (
            <p className={`text-xs ${emailMsg.startsWith("✅") ? "text-emerald-600" : "text-red-500"}`}>
              {emailMsg}
            </p>
          )}
          <button
            type="submit"
            disabled={isLoading}
            className="rounded-lg bg-indigo-600 px-5 py-2 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:opacity-60"
          >
            {isLoading ? t("generic.loading") : t("settings.changeEmail")}
          </button>
        </form>
      </div>

      <hr className="border-slate-200 dark:border-slate-700" />

      {/* {t("settings.changePassword")} */}
      <div>
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-slate-400">
          Change Password
        </h3>
        <form onSubmit={handleChangePassword} className="space-y-3">
          <div>
            <label htmlFor="currentPassword" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Current password
            </label>
            <input
              id="currentPassword" name="currentPassword" type="password"
              className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500 dark:border-slate-600 dark:bg-slate-800 dark:text-white"
            />
          </div>
          <div>
            <label htmlFor="newPassword" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              New password (min. 8 characters)
            </label>
            <input
              id="newPassword" name="newPassword" type="password"
              className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500 dark:border-slate-600 dark:bg-slate-800 dark:text-white"
            />
          </div>
          <div>
            <label htmlFor="confirmNewPassword" className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Confirm new password
            </label>
            <input
              id="confirmNewPassword" name="confirmNewPassword" type="password"
              className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500 dark:border-slate-600 dark:bg-slate-800 dark:text-white"
            />
          </div>
          {passwordMsg && (
            <p className={`text-xs ${passwordMsg.startsWith("✅") ? "text-emerald-600" : "text-red-500"}`}>
              {passwordMsg}
            </p>
          )}
          <button
            type="submit"
            disabled={isLoading}
            className="rounded-lg bg-indigo-600 px-5 py-2 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:opacity-60"
          >
            {isLoading ? t("generic.loading") : t("settings.changePassword")}
          </button>
        </form>
      </div>

      <hr className="border-slate-200 dark:border-slate-700" />

      {/* GDPR Art. 20 — recht op dataportabiliteit */}
      <div>
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-slate-400">
          Download My Data
        </h3>
        <p className="mb-3 text-sm text-slate-500 dark:text-slate-400">
          Download a copy of all your account and progress data as a JSON file.
        </p>
        <button
          type="button"
          onClick={handleExportData}
          disabled={isExporting}
          className="rounded-lg bg-slate-700 px-5 py-2 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:opacity-40"
        >
          {isExporting ? "..." : "Download My Data"}
        </button>
        {exportError && (
          <p className="mt-2 text-sm text-red-500">{exportError}</p>
        )}
      </div>

      <hr className="border-slate-200 dark:border-slate-700" />

      {/* Two-Factor Authentication (optioneel) */}
      <div>
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-slate-400">
          Two-Factor Authentication
        </h3>

        {mfaError && (
          <p className="mb-3 text-sm text-red-500">{mfaError}</p>
        )}

        {mfaLoading ? (
          <p className="text-sm text-slate-500 dark:text-slate-400">Loading…</p>
        ) : mfaEnrolling ? (
          <div className="space-y-4 rounded-lg border border-slate-200 p-4 dark:border-slate-700">
            <p className="text-sm text-slate-600 dark:text-slate-300">
              Scan this QR code with an authenticator app (Google Authenticator, Authy, 1Password, …):
            </p>
            {mfaQrCode && (
              <img src={mfaQrCode} alt="2FA QR code" className="mx-auto h-40 w-40" />
            )}
            <p className="text-center text-xs text-slate-500 dark:text-slate-400">
              Can't scan? Enter this code manually:{" "}
              <code className="rounded bg-slate-100 px-1.5 py-0.5 dark:bg-slate-700">{mfaSecret}</code>
            </p>
            <form onSubmit={handleMfaConfirmEnroll} className="space-y-3">
              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={mfaCode}
                onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, ""))}
                placeholder="000000"
                className="block w-full rounded-lg border border-slate-300 px-4 py-2.5 text-center text-lg tracking-[0.5em] outline-none focus:ring-2 focus:ring-indigo-500 dark:border-slate-600 dark:bg-slate-900 dark:text-white"
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={mfaBusy || mfaCode.length !== 6}
                  className="flex-1 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-40"
                >
                  {mfaBusy ? "..." : "Confirm"}
                </button>
                <button
                  type="button"
                  onClick={handleMfaCancelEnroll}
                  className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-600 dark:text-slate-300 dark:hover:bg-slate-700"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        ) : mfaFactors.length > 0 ? (
          <div className="flex items-center justify-between rounded-lg border border-slate-200 p-4 dark:border-slate-700">
            <div>
              <p className="text-sm font-medium text-slate-900 dark:text-white">✅ 2FA is enabled</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">Your account is protected with an authenticator app.</p>
            </div>
            <button
              type="button"
              onClick={() => handleMfaRemove(mfaFactors[0].id)}
              disabled={mfaBusy}
              className="rounded-lg border border-red-300 px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-50 disabled:opacity-40 dark:border-red-600 dark:text-red-400 dark:hover:bg-red-900/20"
            >
              {mfaBusy ? "..." : "Disable"}
            </button>
          </div>
        ) : (
          <div>
            <p className="mb-3 text-sm text-slate-500 dark:text-slate-400">
              Add an extra layer of security — you'll need a code from your phone in addition to your password when logging in.
            </p>
            <button
              type="button"
              onClick={handleMfaStartEnroll}
              disabled={mfaBusy}
              className="rounded-lg bg-slate-700 px-5 py-2 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-40"
            >
              {mfaBusy ? "..." : "Enable 2FA"}
            </button>
          </div>
        )}
      </div>

      <hr className="border-slate-200 dark:border-slate-700" />

      {/* {t("settings.deleteAccount")} */}
      <div>
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-red-500">
          Delete Account
        </h3>
        <p className="mb-3 text-sm text-slate-500 dark:text-slate-400">
          Type your username <strong>{user.username}</strong> to confirm permanent deletion.
          This cannot be undone.
        </p>
        <div className="flex gap-2">
          <input
            type="text"
            value={deleteInput}
            onChange={(e) => setDeleteInput(e.target.value)}
            placeholder={`Type "${user.username}" to confirm`}
            className="flex-1 rounded-lg border border-red-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-red-500 dark:border-red-600 dark:bg-slate-800 dark:text-white"
          />
          <button type="button" onClick={handleDeleteAccount}
            disabled={deleteInput !== user.username || isDeleting}
            className="rounded-lg bg-red-600 px-5 py-2 text-sm font-semibold text-white transition hover:bg-red-700 disabled:opacity-40"
          >
            {isDeleting ? "..." : "Delete"}
          </button>
        </div>
        {deleteError && (
          <p className="mt-2 text-sm text-red-500">{deleteError}</p>
        )}
      </div>
    </div>
  );
}

// ── Preferences Section ──────────────────────────────────────────────────
function PreferencesSection({
  theme,
  setTheme,
  uiLanguage,
  setUILanguage,
}: {
  theme: string;
  setTheme: (t: "light" | "dark") => void;
  uiLanguage: string;
  setUILanguage: (l: UILanguage) => void;
}) {
  return (
    <div className="space-y-8">
      {/* Theme */}
      <div>
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-slate-400">{t("settings.theme")}</h3>
        <div className="flex gap-3">
          {(["light", "dark"] as const).map((t) => (
            <button type="button" key={t}
              onClick={() => setTheme(t)}
              className={`flex items-center gap-2 rounded-xl border-2 px-5 py-3 text-sm font-medium transition ${
                theme === t
                  ? "border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-900/20 dark:text-indigo-300"
                  : "border-slate-200 text-slate-600 hover:border-slate-300 dark:border-slate-700 dark:text-slate-400"
              }`}
            >
              {t === "light" ? `☀️ ${t("settings.light")}` : `🌙 ${t("settings.dark")}`}
            </button>
          ))}
        </div>
      </div>

      <hr className="border-slate-200 dark:border-slate-700" />

      {/* UI Language */}
      <div>
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-slate-400">
          {t("settings.uiLanguage")}
        </h3>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {UI_LANGUAGES.map((lang) => (
            <button type="button" key={lang.code}
              onClick={() => setUILanguage(lang.code as UILanguage)}
              className={`flex items-center gap-2 rounded-lg border-2 px-4 py-2.5 text-sm font-medium transition ${
                uiLanguage === lang.code
                  ? "border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-900/20 dark:text-indigo-300"
                  : "border-slate-200 text-slate-600 hover:border-slate-300 dark:border-slate-700 dark:text-slate-400"
              }`}
            >
              <span>{lang.flag}</span>
              <span>{lang.name}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Learning Section ─────────────────────────────────────────────────────
function LearningSection({
  user,
  updateProfile,
  navigate,
  t,
}: {
  user: NonNullable<ReturnType<typeof useAuth>["user"]>;
  updateProfile: ReturnType<typeof useAuth>["updateProfile"];
  navigate: ReturnType<typeof useNavigate>;
  t: (key: string) => string;
}) {
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  return (
    <div className="space-y-8">
      {/* ✅ BUG-17: custom modal instead of window.confirm() */}
      {showResetConfirm && (
        <ConfirmModal
          title={t("settings.resetProgress") + "?"}
          message={t("settings.resetWarning")}
          onConfirm={() => {
            updateProfile({ totalXP: 0, level: 1, streak: 0, lastActivityDate: null });
            setShowResetConfirm(false);
            navigate("/dashboard");
          }}
          onCancel={() => setShowResetConfirm(false)}
        />
      )}

      {/* ✅ BUG-10: Learning language — does NOT change interfaceLanguage */}
      <div>
        <h3 className="mb-1 text-sm font-semibold uppercase tracking-wide text-slate-400">
          {t("settings.learningLang")}
        </h3>
        <p className="mb-4 text-xs text-slate-400">
          This changes what language you are learning — not the app language.
        </p>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {LEARNING_LANGUAGES.map((lang) => {
            const isActive = user.currentLanguage === lang.code;
            return (
              <button type="button" key={lang.code}
                // ✅ Only update currentLanguage — NOT interfaceLanguage
                onClick={() => updateProfile({ currentLanguage: lang.code, interfaceLanguage: lang.code })}
                className={`flex items-center gap-2 rounded-lg border-2 px-4 py-2.5 text-sm font-medium transition ${
                  isActive
                    ? "border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-900/20 dark:text-indigo-300"
                    : "border-slate-200 text-slate-600 hover:border-slate-300 dark:border-slate-700 dark:text-slate-400"
                }`}
              >
                <span>{lang.flag}</span>
                <span>{lang.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      <hr className="border-slate-200 dark:border-slate-700" />

      {/* Reset Progress */}
      <div>
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-slate-400">
          {t("settings.resetProgress")}
        </h3>
        <p className="mb-3 text-sm text-slate-500 dark:text-slate-400">
          {t("settings.resetWarning")}
        </p>
        <button type="button" onClick={() => setShowResetConfirm(true)}
          className="rounded-lg border border-red-300 px-5 py-2 text-sm font-semibold text-red-600 transition hover:bg-red-50 dark:border-red-600 dark:text-red-400 dark:hover:bg-red-900/20"
        >
          Reset All Progress
        </button>
      </div>

      <hr className="border-slate-200 dark:border-slate-700" />

      {/* Daily XP Goal */}
      <div>
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-slate-400">
          {t("settings.dailyGoal")}
        </h3>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Default: 50 XP. Custom goals will be available in a future update.
        </p>
      </div>
    </div>
  );
}

// ── AI Settings Section ──────────────────────────────────────────────────
function AISettingsSection() {
  return (
    <div className="space-y-8">
      <div>
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wide text-slate-400">
          Payment &amp; AI Configuration
        </h3>
        <div className="rounded-xl border-2 border-emerald-200 bg-emerald-50 p-4 dark:border-emerald-800 dark:bg-emerald-900/20">
          <p className="text-sm font-bold text-emerald-700 dark:text-emerald-300">
            🔒 Fully Secure — Vercel Deployment
          </p>
          <ul className="mt-2 space-y-1 text-xs text-emerald-600 dark:text-emerald-400">
            <li>• Claude API key → Vercel <code className="rounded bg-white/50 px-1 dark:bg-black/20">ANTHROPIC_API_KEY</code></li>
            <li>• AI requests go to <code className="rounded bg-white/50 px-1 dark:bg-black/20">/api/chat</code> (same domain)</li>
            <li>• Payments via <code className="rounded bg-white/50 px-1 dark:bg-black/20">ko-fi.com/rojhawar</code></li>
            <li>• Zero API keys in browser, GitHub, or frontend</li>
          </ul>
        </div>
      </div>

      <hr className="border-slate-200 dark:border-slate-700" />

      <div>
        <h3 className="mb-2 text-sm font-medium text-slate-700 dark:text-slate-300">{t("settings.aiModel")}</h3>
        <select
          disabled
          value="claude"
          className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-400 dark:border-slate-600 dark:bg-slate-800/50"
        >
          <option value="claude">Claude 3.5 Haiku (active)</option>
          <option value="gpt4">GPT-4 (coming soon)</option>
          <option value="gpt35">GPT-3.5 Turbo (coming soon)</option>
        </select>
      </div>

      <div className="rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 p-4 text-center dark:border-slate-600 dark:bg-slate-800/50">
        <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
          ✅ No API keys in browser or GitHub.
        </p>
        <p className="mt-1 text-xs text-slate-400">
          Deploy to Vercel, set <code className="rounded bg-slate-100 px-1 dark:bg-slate-700">ANTHROPIC_API_KEY</code> in environment variables. Done.
        </p>
      </div>
    </div>
  );
}
