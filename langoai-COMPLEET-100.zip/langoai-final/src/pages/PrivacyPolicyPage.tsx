// src/pages/PrivacyPolicyPage.tsx
// ✅ GDPR-compliant Privacy Policy
//    Gebaseerd op EU GDPR / Belgisch recht
//    Verplichte onderdelen: verwerkingsdoel, rechtsgrond, bewaartermijn,
//    verwerkingsverantwoordelijke, rechten betrokkene, DPA contactgegevens

import { useNavigate } from "react-router-dom";

export default function PrivacyPolicyPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <button
          onClick={() => navigate(-1)}
          className="mb-6 inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-600 shadow-sm transition hover:border-indigo-200 hover:bg-indigo-50 hover:text-indigo-700 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300"
        >
          <span aria-hidden="true">←</span>
          Terug / Back
        </button>

        <h1 className="mb-2 text-3xl font-extrabold text-slate-900 dark:text-white">
          Privacybeleid / Privacy Policy
        </h1>
        <p className="mb-2 text-sm text-slate-500 dark:text-slate-400">
          Laatste update / Last updated: 1 juli 2026
        </p>
        <p className="mb-8 text-xs text-slate-400 dark:text-slate-500">
          Van toepassing op / Applicable to: langoaiapp.vercel.app · België / Belgium · EU GDPR (AVG)
        </p>

        <div className="space-y-10 text-sm leading-relaxed text-slate-700 dark:text-slate-300">

          {/* 1. Verwerkingsverantwoordelijke */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              1. Verwerkingsverantwoordelijke / Data Controller
            </h2>
            <p className="mb-2">
              <strong>Lango AI</strong> is de verwerkingsverantwoordelijke in de zin van de Algemene
              Verordening Gegevensbescherming (AVG / GDPR, Verordening EU 2016/679).
            </p>
            <p className="mb-2">
              <strong>Contactgegevens:</strong><br />
              E-mail: <a href="mailto:privacy@langoai.com" className="text-indigo-600 underline dark:text-indigo-400">privacy@langoai.com</a><br />
              Gevestigd in: België (EU)
            </p>
            <p className="text-xs text-slate-400">
              Als de verwerking significant is, kunnen we verplicht zijn een DPO (Data Protection Officer)
              aan te stellen. Neem contact op voor vragen.
            </p>
          </section>

          {/* 2. Welke data */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              2. Welke persoonsgegevens verwerken wij?
            </h2>

            <div className="overflow-hidden rounded-xl border border-slate-200 dark:border-slate-700">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 dark:bg-slate-800">
                  <tr>
                    <th className="px-4 py-2 font-semibold text-slate-700 dark:text-slate-300">Categorie</th>
                    <th className="px-4 py-2 font-semibold text-slate-700 dark:text-slate-300">Gegevens</th>
                    <th className="px-4 py-2 font-semibold text-slate-700 dark:text-slate-300">Rechtsgrond</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                  {[
                    ["Accountgegevens", "E-mailadres, gebruikersnaam, wachtwoord (versleuteld)", "Uitvoering overeenkomst (art. 6.1.b GDPR)"],
                    ["Leervoortgang", "XP, niveau, streak, voltooide lessen, woordenschat, testresultaten", "Uitvoering overeenkomst (art. 6.1.b GDPR)"],
                    ["Voorkeuren", "Thema, interfacetaal, leertaal, dagelijks doel", "Uitvoering overeenkomst (art. 6.1.b GDPR)"],
                    ["Betalingsdata", "Betaalstatus, bedrag, valuta, Ko-fi transactie-ID, e-mail (via Ko-fi webhook)", "Uitvoering overeenkomst (art. 6.1.b GDPR)"],
                    ["AI Chat berichten", "Berichten die je stuurt aan de AI Tutor (alleen bij actief premium)", "Uitvoering overeenkomst (art. 6.1.b GDPR)"],
                    ["Technische data", "IP-adres (rate limiting), sessiegegevens, browser localStorage", "Gerechtvaardigd belang (art. 6.1.f GDPR) — veiligheid"],
                  ].map(([cat, data, grond]) => (
                    <tr key={cat} className="bg-white dark:bg-slate-900">
                      <td className="px-4 py-2 font-medium text-slate-800 dark:text-slate-200">{cat}</td>
                      <td className="px-4 py-2 text-slate-600 dark:text-slate-400">{data}</td>
                      <td className="px-4 py-2 text-slate-500 dark:text-slate-500">{grond}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <p className="mt-3 text-xs text-slate-400">
              ⚠️ Wij verwerken <strong>geen</strong> bijzondere categorieën persoonsgegevens
              (gezondheid, ras, politieke opvattingen, etc.) — art. 9 GDPR.
            </p>
          </section>

          {/* 3. Doel */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              3. Waarvoor gebruiken wij jouw gegevens?
            </h2>
            <ul className="ml-5 list-disc space-y-1">
              <li>Aanmaken en beheren van jouw account</li>
              <li>Leveren van de taalleerservice (lessen, tests, XP, streak)</li>
              <li>Verifiëren van betalingen en vrijgeven van AI Premium (30 dagen)</li>
              <li>Beveiligen van de service (rate limiting, misbruikdetectie)</li>
              <li>Tonen van advertenties aan gratis gebruikers (Google AdSense)</li>
              <li>AI Tutor berichten verwerken via Claude API (alleen bij actief premium)</li>
            </ul>
            <p className="mt-2 text-xs text-red-500 dark:text-red-400 font-medium">
              ❌ Wij verkopen jouw persoonsgegevens NIET aan derden.
            </p>
          </section>

          {/* 4. Bewaartermijnen */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              4. Hoe lang bewaren wij jouw gegevens? (Bewaartermijnen)
            </h2>
            <ul className="ml-5 list-disc space-y-1">
              <li><strong>Accountgegevens:</strong> Zolang je account actief is. Bij verwijdering binnen 30 dagen gewist.</li>
              <li><strong>Leervoortgang:</strong> Zolang je account bestaat.</li>
              <li><strong>Betalingsdata:</strong> 7 jaar (wettelijke boekhoudplicht — België).</li>
              <li><strong>AI Chat berichten:</strong> Niet bewaard op onze servers. Verwerkt door Claude API per sessie.</li>
              <li><strong>IP-adres (rate limiting):</strong> Max. 60 seconden in geheugen, niet opgeslagen.</li>
              <li><strong>Browser localStorage:</strong> Blijft op jouw apparaat tot je het zelf wist of je account verwijdert.</li>
            </ul>
          </section>

          {/* 5. Doorgifte */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              5. Doorgifte aan derden
            </h2>
            <div className="space-y-3">
              {[
                {
                  name: "Supabase (database & authenticatie)",
                  info: "Opslag van accountgegevens en leervoortgang. Supabase is AVG-compliant en heeft servers in de EU beschikbaar.",
                  link: "https://supabase.com/privacy",
                },
                {
                  name: "Vercel (hosting & serverless functies)",
                  info: "Hosting van de website en API. Vercel is gevestigd in de VS maar is GDPR-compliant (Standard Contractual Clauses).",
                  link: "https://vercel.com/legal/privacy-policy",
                },
                {
                  name: "Anthropic / Claude API (AI Tutor)",
                  info: "AI Chat berichten worden doorgestuurd naar Anthropic om antwoorden te genereren. Alleen bij actief premium.",
                  link: "https://www.anthropic.com/privacy",
                },
                {
                  name: "Ko-fi & PayPal (betalingen)",
                  info: "Betaalverwerking. Ko-fi stuurt een webhook met betalingsbevestiging naar onze server.",
                  link: "https://ko-fi.com/privacy",
                },
                {
                  name: "Google AdSense (advertenties)",
                  info: "Toont advertenties aan gratis gebruikers. Google kan cookies plaatsen voor gepersonaliseerde advertenties.",
                  link: "https://policies.google.com/privacy",
                },
              ].map((item) => (
                <div key={item.name} className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
                  <p className="font-semibold text-slate-800 dark:text-slate-200">{item.name}</p>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{item.info}</p>
                  <a href={item.link} target="_blank" rel="noopener noreferrer"
                    className="mt-1 text-xs text-indigo-600 underline hover:text-indigo-500 dark:text-indigo-400">
                    Privacybeleid →
                  </a>
                </div>
              ))}
            </div>
          </section>

          {/* 6. Jouw rechten */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              6. Jouw rechten onder de GDPR
            </h2>
            <p className="mb-3">
              Als betrokkene heb je de volgende rechten (artt. 15–22 GDPR):
            </p>
            <div className="grid gap-2 sm:grid-cols-2">
              {[
                ["📋 Recht op inzage", "Je mag opvragen welke gegevens wij over jou bewaren."],
                ["✏️ Recht op rectificatie", "Je mag onjuiste gegevens laten corrigeren."],
                ["🗑️ Recht op wissing", "Je mag vragen al jouw gegevens te verwijderen ('recht om vergeten te worden')."],
                ["⏸️ Recht op beperking", "Je mag verwerking laten beperken in bepaalde gevallen."],
                ["📦 Recht op overdraagbaarheid", "Je mag jouw gegevens in een leesbaar formaat opvragen."],
                ["❌ Recht op bezwaar", "Je mag bezwaar maken tegen verwerking op basis van gerechtvaardigd belang."],
                ["🚫 Recht tegen geautomatiseerde besluitvorming", "Wij nemen geen geautomatiseerde besluiten met rechtsgevolgen."],
                ["↩️ Recht intrekken toestemming", "Als verwerking op toestemming is gebaseerd, kun je die intrekken."],
              ].map(([title, desc]) => (
                <div key={title} className="rounded-xl border border-slate-200 bg-white p-3 dark:border-slate-700 dark:bg-slate-900">
                  <p className="text-xs font-bold text-slate-800 dark:text-slate-200">{title}</p>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{desc}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-xl border border-indigo-200 bg-indigo-50 p-4 dark:border-indigo-800 dark:bg-indigo-950/20">
              <p className="text-xs font-semibold text-indigo-800 dark:text-indigo-300">
                📧 Rechten uitoefenen?
              </p>
              <p className="mt-1 text-xs text-indigo-700 dark:text-indigo-400">
                Stuur een e-mail naar{" "}
                <a href="mailto:privacy@langoai.com" className="underline">privacy@langoai.com</a>.
                Wij reageren binnen <strong>30 dagen</strong> (wettelijke termijn art. 12 GDPR).
              </p>
            </div>
          </section>

          {/* 7. Klachten */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              7. Klachten — Toezichthouder
            </h2>
            <p className="mb-2">
              Als je vindt dat wij jouw gegevens onrechtmatig verwerken, heb je het recht een klacht in te
              dienen bij de bevoegde toezichthouder:
            </p>
            <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
              <p className="font-semibold text-slate-800 dark:text-slate-200">
                🇧🇪 Gegevensbeschermingsautoriteit (GBA) — België
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Drukpersstraat 35, 1000 Brussel<br />
                Tel: +32 2 274 48 00<br />
                Website:{" "}
                <a href="https://www.gegevensbeschermingsautoriteit.be" target="_blank" rel="noopener noreferrer"
                  className="text-indigo-600 underline dark:text-indigo-400">
                  gegevensbeschermingsautoriteit.be
                </a>
              </p>
            </div>
          </section>

          {/* 8. Cookies */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              8. Cookies en localStorage
            </h2>
            <p className="mb-2">
              Wij gebruiken <strong>browser localStorage</strong> (geen tracking cookies) voor:
            </p>
            <ul className="ml-5 list-disc space-y-1">
              <li>Inlogstatus en sessiebeheer (noodzakelijk)</li>
              <li>Leervoortgang, streak, XP (noodzakelijk)</li>
              <li>Thema en taalvoorkeur (functioneel)</li>
              <li>AI Premium toegangsstatus (noodzakelijk)</li>
            </ul>
            <p className="mt-2 text-xs text-slate-400">
              Google AdSense kan cookies plaatsen voor advertentiepersonalisatie.
              Je kunt dit beheren via jouw browserinstellingen of{" "}
              <a href="https://adssettings.google.com" target="_blank" rel="noopener noreferrer"
                className="text-indigo-600 underline dark:text-indigo-400">
                Google Advertentie-instellingen
              </a>.
            </p>
          </section>

          {/* 9. Beveiliging */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              9. Beveiliging
            </h2>
            <ul className="ml-5 list-disc space-y-1">
              <li>Wachtwoorden worden versleuteld opgeslagen (Supabase bcrypt)</li>
              <li>Alle verbindingen via HTTPS/TLS</li>
              <li>API-sleutels bewaard op beveiligde servers (nooit in browser)</li>
              <li>Row Level Security (RLS) — elke gebruiker ziet alleen eigen data</li>
              <li>Rate limiting op API-eindpunten</li>
              <li>HTTP security headers (CSP, X-Frame-Options, HSTS)</li>
            </ul>
          </section>

          {/* 10. Minderjarigen */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              10. Minderjarigen
            </h2>
            <p>
              Lango AI is niet gericht op kinderen onder de <strong>16 jaar</strong> (conform Belgisch recht,
              art. 8 GDPR). Als je weet dat een minderjarige gegevens heeft verstrekt, neem dan contact
              op via privacy@langoai.com zodat wij de gegevens kunnen verwijderen.
            </p>
          </section>

          {/* 11. Wijzigingen */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              11. Wijzigingen in dit beleid
            </h2>
            <p>
              Wij kunnen dit privacybeleid bijwerken. Bij wezenlijke wijzigingen informeren wij je via
              de app of per e-mail. De datum bovenaan geeft aan wanneer het beleid voor het laatst is
              bijgewerkt. Voortgezet gebruik na wijziging houdt in dat je het nieuwe beleid accepteert.
            </p>
          </section>

          {/* 12. Contact */}
          <section>
            <h2 className="mb-3 text-lg font-bold text-slate-900 dark:text-white">
              12. Contact
            </h2>
            <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
              <p className="text-xs text-slate-600 dark:text-slate-300">
                📧{" "}
                <a href="mailto:privacy@langoai.com" className="font-semibold text-indigo-600 underline dark:text-indigo-400">
                  privacy@langoai.com
                </a>
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Reactie binnen 30 dagen (wettelijke GDPR-termijn).
              </p>
            </div>
          </section>

        </div>
      </div>
    </div>
  );
}
