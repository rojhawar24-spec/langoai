// src/pages/ProfilePage.tsx
// ✅ Alle teksten via t() — geen hardcoded Engels meer

import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useTranslate } from "@/i18n/I18nContext";
import { xpForNextLevel, xpRequiredForLevel } from "@/utils/xp";
import { computeStreak, getLast7Days } from "@/utils/streak";
import { useStreakReconciler } from "@/hooks/useStreakReconciler";
import { formatPremiumExpiry, isPremiumActive } from "@/utils/apiConfig";

const LEARNING_LANGUAGES = [
  { code: "en", name: "English", flag: "🇬🇧" },
  { code: "nl", name: "Dutch",   flag: "🇳🇱" },
  { code: "fr", name: "French",  flag: "🇫🇷" },
  { code: "de", name: "German",  flag: "🇩🇪" },
  { code: "es", name: "Spanish", flag: "🇪🇸" },
];

export default function ProfilePage() {
  const { user }  = useAuth();
  const navigate  = useNavigate();
  const { t }     = useTranslate();
  useStreakReconciler();

  if (!user) return null;

  const premiumActive    = isPremiumActive(user);
  const premiumExpiresAt = user.premiumExpiresAt ??
    localStorage.getItem("langlearn_payment_expires_at");

  const { streak: currentStreak } = useMemo(() => computeStreak(), [user.streak]);
  const last7Days = useMemo(() => getLast7Days(), [user.streak]);

  const xpNeededForNext = xpForNextLevel(user.level);
  const xpCurrent       = user.totalXP - xpRequiredForLevel(user.level);
  const xpProgress      = Math.min((xpCurrent / xpNeededForNext) * 100, 100);

  const initials    = user.username.slice(0, 2).toUpperCase();
  const memberSince = new Date(user.createdAt).toLocaleDateString(undefined, {
    year: "numeric", month: "long", day: "numeric",
  });
  const longestStreak      = Math.max(currentStreak, user.streak ?? 0);
  const activeDaysThisWeek = last7Days.filter((d) => d.active).length;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <div className="mx-auto max-w-3xl px-4 py-8 pb-28 sm:px-6">

        {/* Terug knop */}
        <button type="button" onClick={() => navigate("/dashboard")}
          aria-label={t("profile.backToDashboard")}
          className="mb-6 flex items-center gap-1 text-sm text-slate-500 transition hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400"
        >
          <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          {t("profile.backToDashboard")}
        </button>

        {/* Avatar + naam */}
        <div className="mb-6 flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 text-2xl font-bold text-white shadow-lg">
            {initials}
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white">
              {user.username}
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              {t("profile.member_since")} {memberSince}
            </p>
            {premiumActive && (
              <span className="mt-1 inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">
                ⭐ {t("profile.premium_member")}
              </span>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { label: t("profile.totalXP"),        value: user.totalXP.toLocaleString(), icon: "⚡" },
            { label: t("profile.levelStat"),       value: String(user.level),            icon: "🏅" },
            { label: t("profile.currentStreak"),   value: `${currentStreak}`,            icon: "🔥" },
            { label: t("profile.thisWeek"),        value: `${activeDaysThisWeek}/7`,     icon: "📅" },
          ].map((s) => (
            <div key={s.label}
              className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800"
            >
              <p className="text-2xl">{s.icon}</p>
              <p className="text-2xl font-extrabold text-slate-900 dark:text-white">{s.value}</p>
              <p className="text-xs text-slate-500">{s.label}</p>
            </div>
          ))}
        </div>

        {/* XP voortgangsbalk */}
        <div className="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
          <div className="mb-2 flex items-center justify-between">
            <p className="font-semibold text-slate-900 dark:text-white">
              {t("profile.levelProgress")}
            </p>
            <span className="text-sm text-slate-500">{xpCurrent} / {xpNeededForNext} XP</span>
          </div>
          <div className="h-3 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-700">
            <div
              className="h-full rounded-full bg-indigo-500 transition-all duration-500"
              style={{ width: `${xpProgress}%` }}
            />
          </div>
        </div>

        {/* Laatste 7 dagen */}
        <div className="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
          <p className="mb-3 font-semibold text-slate-900 dark:text-white">
            {t("profile.thisWeek")}
          </p>
          <div className="flex gap-1.5">
            {last7Days.map((day) => (
              <div key={day.date} className="flex flex-1 flex-col items-center gap-1">
                <div className={`h-8 w-full rounded-lg transition-colors ${
                  day.active
                    ? "bg-indigo-500"
                    : day.isToday
                    ? "border-2 border-indigo-300 bg-slate-100 dark:border-indigo-700 dark:bg-slate-700"
                    : "bg-slate-100 dark:bg-slate-700"
                }`} />
                <span className="text-[9px] text-slate-400">{day.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Taal */}
        <div className="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
          <p className="mb-3 font-semibold text-slate-900 dark:text-white">
            {t("profile.currently_learning")}
          </p>
          <div className="flex flex-wrap gap-2">
            {LEARNING_LANGUAGES.map((lang) => {
              const isActive = user.currentLanguage === lang.code;
              return (
                <span key={lang.code}
                  className={`flex items-center gap-2 rounded-full px-3 py-1.5 text-sm font-medium ${
                    isActive
                      ? "bg-indigo-600 text-white"
                      : "bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400"
                  }`}
                >
                  {lang.flag} {lang.name}
                  {isActive && <span className="text-xs opacity-75">✓</span>}
                </span>
              );
            })}
          </div>
        </div>

        {/* Badges */}
        <div className="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
          <p className="mb-3 font-semibold text-slate-900 dark:text-white">
            {t("profile.achievements")}
          </p>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {[
              { icon: "⭐", label: t("profile.firstLesson"),    earned: user.totalXP > 0       },
              { icon: "🎯", label: t("profile.goalCrusher"),    earned: user.totalXP >= 100    },
              { icon: "📚", label: t("profile.scholar"),        earned: user.totalXP >= 500    },
              { icon: "💪", label: t("profile.xpWarrior"),      earned: user.totalXP >= 1000   },
              { icon: "🔥", label: t("profile.sevenDayStreak"), earned: longestStreak >= 7     },
              { icon: "🏆", label: t("profile.thirtyDayStreak"),earned: longestStreak >= 30    },
            ].map((badge) => (
              <div key={badge.label}
                className={`flex flex-col items-center gap-1 rounded-xl border p-3 text-center transition ${
                  badge.earned
                    ? "border-indigo-200 bg-indigo-50 dark:border-indigo-800 dark:bg-indigo-900/20"
                    : "border-slate-200 bg-slate-50 opacity-40 dark:border-slate-700 dark:bg-slate-800"
                }`}
              >
                <span className="text-2xl">{badge.icon}</span>
                <span className="text-[10px] font-medium text-slate-600 dark:text-slate-300">
                  {badge.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Premium status */}
        {premiumActive && premiumExpiresAt && (
          <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 dark:border-amber-800 dark:bg-amber-900/20">
            <p className="text-sm font-medium text-amber-800 dark:text-amber-300">
              ⭐ AI access active until {formatPremiumExpiry(premiumExpiresAt)}.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
