// src/pages/ResetPasswordPage.tsx
// ✅ Pagina waar Supabase naartoe redirect na klikken reset link

import { useState, useEffect, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabase";

export default function ResetPasswordPage() {
  const navigate            = useNavigate();
  const [newPw,     setNewPw]     = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [error,     setError]     = useState("");
  const [success,   setSuccess]   = useState(false);
  const [loading,   setLoading]   = useState(false);
  const [validLink, setValidLink] = useState(false);

  useEffect(() => {
    // Supabase stuurt token via URL hash — controleer sessie
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) setValidLink(true);
      else setValidLink(false);
    });
  }, []);

  async function handleReset(e: FormEvent) {
    e.preventDefault();
    setError("");

    if (newPw.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    if (newPw !== confirmPw) {
      setError("Passwords do not match.");
      return;
    }

    setLoading(true);
    const { error: supaErr } = await supabase.auth.updateUser({ password: newPw });

    if (supaErr) {
      setError("Could not reset password. Please try again.");
    } else {
      setSuccess(true);
      setTimeout(() => navigate("/login", { replace: true }), 3000);
    }
    setLoading(false);
  }

  if (!validLink) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4 dark:bg-slate-900">
        <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm dark:border-slate-700 dark:bg-slate-800">
          <p className="text-4xl">⚠️</p>
          <h1 className="mt-4 text-xl font-bold text-slate-900 dark:text-white">Invalid or expired link</h1>
          <p className="mt-2 text-sm text-slate-500">This password reset link is no longer valid.</p>
          <button
            onClick={() => navigate("/login")}
            className="mt-6 rounded-lg bg-indigo-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700"
          >
            Back to login
          </button>
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4 dark:bg-slate-900">
        <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm dark:border-slate-700 dark:bg-slate-800">
          <p className="text-5xl">✅</p>
          <h1 className="mt-4 text-xl font-bold text-slate-900 dark:text-white">Password changed!</h1>
          <p className="mt-2 text-sm text-slate-500">Redirecting to login...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4 py-12 dark:bg-slate-900">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Set new password</h1>
          <p className="mt-1 text-sm text-slate-500">Enter your new password below.</p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm dark:border-slate-700 dark:bg-slate-800">
          {error && (
            <div role="alert" className="mb-4 rounded-lg bg-red-50 px-4 py-3 text-sm text-red-600 dark:bg-red-900/30 dark:text-red-400">
              {error}
            </div>
          )}

          <form onSubmit={handleReset} className="space-y-5" noValidate>
            <div>
              <label htmlFor="newPw" className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                New password (min. 8 characters)
              </label>
              <input
                id="newPw"
                type="password"
                autoComplete="new-password"
                value={newPw}
                onChange={(e) => setNewPw(e.target.value)}
                className="mt-1 block w-full rounded-lg border border-slate-300 px-4 py-2.5 text-sm outline-none transition focus:ring-2 focus:ring-indigo-500 dark:border-slate-600 dark:bg-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label htmlFor="confirmPw" className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                Confirm new password
              </label>
              <input
                id="confirmPw"
                type="password"
                autoComplete="new-password"
                value={confirmPw}
                onChange={(e) => setConfirmPw(e.target.value)}
                className="mt-1 block w-full rounded-lg border border-slate-300 px-4 py-2.5 text-sm outline-none transition focus:ring-2 focus:ring-indigo-500 dark:border-slate-600 dark:bg-slate-900 dark:text-white"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-700 disabled:opacity-60"
            >
              {loading && <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />}
              Change password
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
